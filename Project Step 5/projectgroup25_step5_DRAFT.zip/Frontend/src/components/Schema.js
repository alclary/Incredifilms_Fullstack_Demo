import React from "react";

export default function Schema() {
  return (
    <div className="" id="schemaGraph">
<h3>Schema</h3>
<img src="../images/schema.png" alt="Schema"></img>

</div>
  );
}
