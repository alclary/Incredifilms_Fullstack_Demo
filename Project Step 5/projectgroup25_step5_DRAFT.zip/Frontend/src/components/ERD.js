import React from "react";

export default function ERD() {
  return (
    <div>
<h3>Entity Resource Diagram</h3>
<img src="../images/erd.png" alt="ERD"></img>

</div>
  );
}
